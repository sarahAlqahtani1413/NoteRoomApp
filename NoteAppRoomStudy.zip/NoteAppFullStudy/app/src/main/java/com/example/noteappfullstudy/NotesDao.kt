package com.example.noteappfullstudy

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface NotesDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
   suspend fun insert(note:Note)

   @Query("SELECT * FROM note")
   suspend fun getALL():List<Note>

   @Update
   suspend fun update(note: Note)

   @Delete
   suspend fun delete(note: Note)

}
//@Dao
//interface PersonDao {
//    @Query("SELECT * FROM students ORDER BY pk ASC")
//    fun getPeople(): List<Person>
//
//    @Update
//    suspend fun updatePerson(person: Person)
//
//    @Delete
//    suspend fun deletePerson(person: Person)
//}