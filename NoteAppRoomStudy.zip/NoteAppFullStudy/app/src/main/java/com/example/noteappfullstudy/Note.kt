package com.example.noteappfullstudy

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "note")
data class Note(
  @PrimaryKey(autoGenerate = true)  val noteId:Int?,
    val name:String)



//@Entity(tableName = "students")
//data class Person(
//    @PrimaryKey(autoGenerate = true) val pk: Int,
//    val name: String,
//    val location: String)